package longmethod.java.base_case;

public class LongMethodTestClass {
	public void shortMethod() {
		System.out.println("Short method...");
	}

	public void longMethod() {
		
		System.out.println("Long method...");
		// Comment #1
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		/**
		 * Comment #2
		 */
		System.out.println("Long method...");
		/*
		 * Comment #3
		 */
	}
}
