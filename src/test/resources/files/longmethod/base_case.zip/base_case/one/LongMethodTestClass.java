package one;

public class LongMethodTestClass {
	public void shortMethod() {
		System.out.println("Short method...");
	}

	public void longMethod() {
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
		System.out.println("Long method...");
	}
}
